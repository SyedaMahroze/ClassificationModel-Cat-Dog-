import streamlit as st
import keras
import numpy as np
from PIL import Image
from keras.models import load_model

# ---------------- Load Trained Model ----------------
MODEL_PATH = "Classification_model.keras"

try:
    # Try loading full model
    model = load_model(MODEL_PATH, compile=False, safe_mode=False)
except Exception as e:
    st.error(f"Error loading model: {e}")
    st.stop()

# Define class names (update based on your dataset)
class_names = ["Cat", "Dog"]

# ---------------- Streamlit UI ----------------
st.set_page_config(page_title="AI Image Classifier", layout="centered")
st.title("📷 AI-Powered Image Classifier")
st.write("Upload an image and let the AI predict its class.")

# File uploader
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Display image
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Preprocess image
    img = image.resize((224, 224))
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # Prediction
    predictions = model.predict(img_array)
    pred_class = class_names[np.argmax(predictions)]
    confidence = np.max(predictions) * 100

    # Show result
    st.subheader("Prediction Result")
    st.write(f"**Class:** {pred_class}")
    st.write(f"**Confidence:** {confidence:.2f}%")

st.write("---")
st.write("Developed with ❤️ using Streamlit & Keras")
